It seems the computer labs do not have 7zip linked to the extension .7z; in this case:

- Right-click on the file to be uncompressed and select:
  Open with...->More apps->Look for another app on this PC
- Then select: "C:\Program Files (x86)\7-Zip\7zFM"
- Once 7z launches you can select Extract

A proper installation should have the extract command directly from the right-click menu.
