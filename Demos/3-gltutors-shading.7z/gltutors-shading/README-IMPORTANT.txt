
These files use the old API of OpenGL, so you CANNOT make the same type of calls in your projects. This is why we are not including the source code of these example programs.

Functions glLight() and glMaterial() do not exist anymore, but we are implementing similar functionality in our shaders.

