
The newest versions of OpenGL do not have anymore the
functions GlColor, glBegin, glEnd, and glTextCoord2f
as shown in this demo, but the same parameters are
set with vertex arrays and the same functionality
can be obtained.

You should use this demos application to see how
the many parameters affect the texture mapping and 
not as a programming guide.
